package chapter_project2;

import java.util.ArrayList;
import java.util.Date;

public class Chapter_project2 {

    public static void main(String[] args) {
                      
        Employee e1 = new Employee("ali", "khalil", "muhammad", "nada", "ali123", "1010", new Date("1/1/2024 09:10:58"));
        Employee e2 = new Employee("rami", "alaa", "saad", "rema", "rami123", "9856", new Date("3/5/2024 07:08:08"));
        Employee e3 = new Employee("omar", "khalil", "muhammad", "nada", "omar123", "5456", new Date("6/6/2024 11:59:15"));
        Employee.addEmployee(e1);
        Employee.addEmployee(e2);
        Employee.addEmployee(e3);
        
        //  السؤال الثاني
        /*
        System.out.println("question number 2:");
        System.out.println("check ali account: "+Employee.checkAccount(e1.getUsername(),e1.getPassword())); 
        System.out.println("check amer account: "+Employee.checkAccount("amer11","1234")); 
        System.out.println("----------------------------");
*/
        Project pro1 = new Project("Snake", "A snake that walks and eats apples. If it touches itself, it dies.");
        Project pro2 = new Project("Mario", "A game about the character Mario, who seeks to free his detained friend, going through different stages and monsters.");
        Project pro3 = new Project("City Builder", "It is a simulation game where the player plans, builds and develops a city from scratch, managing resources and infrastructure to achieve sustainable growth and happiness of the residents.");
        Project.addProject(pro1);
        Project.addProject(pro2);
        Project.addProject(pro3);

        Plan p1 = new Plan("Snake game plan 1", "1/6/2024", "3/6/2024", "Day 1 Planning and preparing the project and programming the snake's movement and food collection, Day 2 Designing a simple interface and improving the graphics, rapid testing and launch.");
        Plan p2 = new Plan("Snake game plan 2", "1/6/2024", "2/6/2024", "In the morning planning and preparation, in the afternoon programming the movement and food, in the afternoon designing the interface, and in the evening testing and launching.");
        Plan p3 = new Plan("mario game plan", "1/6/2024", "8/6/2024", "Day 1: Planning, Day 2: Project preparation and movement, Day 3: Designing levels and enemies, Day 4: Game mechanics, Day 5: Graphics and audio, Day 6: Testing and optimization, Day 7: Final touches and launch.");
        Plan p4 = new Plan("City Builder plan", "1/7/2024", "1/8/2024", "Week 1 Planning and Design, Week 2 Preparing the Project and Building System, Week 3 Designing Levels and Assets, Week 4 Improving Graphics and Audio, Testing and Launching.");

        Plan.addPlan(p1);
        Plan.addPlan(p2);
        Plan.addPlan(p3);
        Plan.addPlan(p4);
        //الربط بين plan and project
        p1.project = pro1;
        p2.project = pro1;
        p3.project = pro2;
        p4.project = pro3;
        pro1.addPlan(p1);
        pro1.addPlan(p2);
        pro2.addPlan(p3);
        pro3.addPlan(p4);

        //---------------------------------------
        //هون في مهام اكتملت في الوقت المتوقع وفي لا خلي الفكرة ببالك
        //  1 لعبة الثعبان الخطة 
        Task t1 = new Task("Programming snake movement", new Date("1/1/2024 12:00:00"), new Date("2/1/2024 12:00:00"), "it's ali task.", 24);
        //اكتملت   
        t1.completeTask( new Date("2/1/2024 12:00:00"));

        //  2لعبة الثعبان الخطة 
        Task t2 = new Task("planning and preparation", new Date("1/6/2024 08:00:00"), new Date("1/6/2024 12:00:00"), "it's omar task.", 4);
        t2.completeTask( new Date("1/6/2024 12:00:00"));

        //   3 اكتملت لكن ليس في الوقت المتوقع لعبة ماريو مهمة اليوم 
        Task t3 = new Task("Designing levels and enemies", new Date("3/6/2024 12:00:00"), new Date("4/6/2024 12:00:00"), "it's ali task.", 24);
        t3.completeTask( new Date("6/6/2024 00:00:00"));

        //    (3و4)لعبة بناء المدينة مهمة الاسبوع  
        Task t4 = new Task("Designing Levels and Assets.", new Date("17/1/2024 12:00:00"), new Date("24/7/2024 12:00:00"), "it's rami task.", 168);
        Task t5 = new Task("Improving Graphics and Audio, Testing and Launching.", new Date("24/7/2024 12:00:00"), new Date("1/8/2024 00:00:00"), "it's omar task.", 168);
        Task.addTask(t1);
        Task.addTask(t2);
        Task.addTask(t3);
        Task.addTask(t4);
        Task.addTask(t5);
        //الربط بين plan and task
        t1.plan = p1;
        t2.plan = p2;
        t3.plan = p3;
        t4.plan = p4;
        t5.plan = p4;
        p1.addTask(t1);
        p2.addTask(t2);
        p3.addTask(t3);
        p4.addTask(t4);
        p4.addTask(t5);
        //-------------------------------   
        // الربط بينemployee and task
        e1.addTask(t1);
        e1.addTask(t3);
        e2.addTask(t4);
        e3.addTask(t2);
        e3.addTask(t5);
        t1.employee = e1;
        t2.employee = e3;
        t3.employee = e1;
        t4.employee = e2;
        t5.employee = e3;
        //-------------------------------
        Comment c1 = new Comment("no problem here ,I finished my work on plan 1 for ~Snake Game~ ");
        e1.comments.add(c1);// تعليق علي في المهمة الاولى
        Comment c2 = new Comment("I planned and prepared at the expected time");
        e3.comments.add(c2);//تعليق عمر في المهمة الثانية
        Comment c3 = new Comment("I will improve the graphics and sound.");
        e3.comments.add(c3);//تعليق عمر في المهمة الخامسة
        Comment c4 = new Comment("fine, When you finish, I will put my finishing touches and launch the game.");
        e2.comments.add(c4);//تعليق رامي في المهمة الخامسة
        Comment.addComment(c1);
        Comment.addComment(c2);
        Comment.addComment(c3);
        Comment.addComment(c4);
        //الربط بين comment and comment
        c4.comment = c3;
        c3.addReplie(c4);

        //-----------------------------
        //        الربط بين comments and employee
        c1.employee = e1;
        c2.employee = e3;
        c3.employee = e3;
        c4.employee = e2;
        //--------------------------------
        //        الربط بين plan and comment
        p1.addComment(c1);
        p2.addComment(c2);
        p4.addComment(c3);
        p4.addComment(c4);

        c1.plan = p1;
        c2.plan = p2;
        c3.plan = p4;
        c4.plan = p4;
        // -------------طباعة كل المعلومات بشكل مخنصر عن كل كلاس والقليل من امعلومات المترابطة  -----------------
/*
        Project.printDataOfAllProjects();
        System.out.println("");
        Plan.printDataOfAllPlans();
        System.out.println("");
        Task.printDataOfAllTasks();
        System.out.println("");
        Employee.printDataOfAllEmployee();
        System.out.println("");
        Comment.printDataOfAllComment();
        System.out.println("");
*/
/*       
//        اهم دالة تعرض كل المعلومات من كل الكلاسات المترابطة مع المشروع الواحد
        pro1.projectInformation();
        pro2.projectInformation();
        pro3.projectInformation();
*/    
/*
    // ارجاع المهام بين تاريخين لا تتجاوز المدة اسبوع (i)الطلب 
        Date startDate=new Date("1/1/2024 12:00:00");
        Date endDate=new Date("5/1/2024 12:00:00");
        ArrayList<Task> completedTasks = Task.getCompletedTasksInWeek(startDate, endDate);
        if (completedTasks.isEmpty()) {
            System.out.println("THERE ARE NO TASKS COMPLETED BWTWEEN:   "+startDate+"   AND: "+endDate);
        }
        for (Task task : completedTasks) {
        System.out.println("COMPLETED TASKS BWTWEEN:   "+startDate+"   AND: "+endDate+"  :");
            System.out.println("TASK\tID: "+task.getId()+"\tNAME: " + task.taskName + "\nCOMPLETED DATE: " + task.completedDate);
        }
*/
/*
//  j,kالطلب   
        for (Task task:Task.tasks) {
            if (task.getNumberOfExpectedTime(task.startDate,task.endDate) == 0) {
                System.out.println("TASK \tID: "+task.getId()+"\tIT TOOK LIKE EXPECTED TIME(0).");
            }else if(task.getNumberOfExpectedTime(task.startDate,task.endDate) == 1){
                System.out.println("TASK \tID: "+task.getId()+"\tIT TOOK LONGER THEN EXPECTED TIME(1).");
            }else if (task.getNumberOfExpectedTime(task.startDate,task.endDate) == -1) {
                System.out.println("TASK \tID: "+task.getId()+"\tIT TOOK LESS THEN EXPECTED TIME(-1).");
            }
                
        }
*/
    }
}
