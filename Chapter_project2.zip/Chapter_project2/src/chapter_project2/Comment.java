package chapter_project2;

import java.util.ArrayList;

public class Comment {

    private static int lastCommentId = 0;
    private int id;
    String commentText;
    Employee employeeId;
    Plan planId;
    //قائمة ساكنة تخزين جميع التعليقات 
    public static ArrayList<Comment> comments = new ArrayList<>();
    //    التعليق يملك ردود
    public static ArrayList<Comment> replies = new ArrayList<>();
    Comment comment;//fk3
    Employee employee;//fk2
    Plan plan;//fk1

    public Comment(String commentText) {
        this.id = ++lastCommentId;
        this.commentText = commentText;
        lastCommentId = this.id;
    }

    public void addReplie(Comment replie) {
        replies.add(replie);

    }

    public int getId() {
        return id;
    }

    public static void addComment(Comment newComment) {
        comments.add(newComment);
    }
    //دالة طباعة كل التعليقات 
     public static void printDataOfAllComment() {
        if (comments.isEmpty()) {
                System.out.println("THERE ARE NO COMMETNS...");
        }
        else{
            System.out.println("-------ALL COMMETNS-------");
            int counter=1;
            for (Comment comment : comments) {
                System.out.println("``COMMETNS NUMBER("+counter+"):");
                System.out.println("ID: " + comment.id);
                System.out.println("Text: " + comment.commentText);
                System.out.println("Commenter's username : " + comment.employee.username);
                System.out.println("Comment on the plan:"+comment.plan.planName);
                for (Comment replie : replies) {
                    if (comment.commentText.equals(replie.commentText)) {
                        System.out.println("THIS COMMENT IS A REPLIE ON COMMENT THAT ID("+replie.comment.getId()+").");
                    }
                }
                System.out.println("----------------");
                counter++;
            }
        }
    }
   
}
            
