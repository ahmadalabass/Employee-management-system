package chapter_project2;

import java.util.ArrayList;

public class Project {

    private static int lastProjectId = 0;
    private int projectId;
    String projectName;
    String description;
    // قائمة تخزين الخطط المتعلقة بالمشروع
     ArrayList<Plan> plans = new ArrayList<>();
    // قائمة ساكنة لتخزين جميع المشاريع
    static ArrayList<Project> projects = new ArrayList<>();

    public Project(String projectName, String description) {
        this.projectId = ++lastProjectId;
        this.projectName = projectName;
        this.description = description;
        lastProjectId = this.projectId;
    }

    public int getProjectId() {
        return projectId;
    }
    // دالة لإضافة مشروع جديد إلى قائمة مشاريع
    public static void addProject(Project newProject) {
        projects.add(newProject);
    }
    
    public void addPlan(Plan newPlan) {
        plans.add(newPlan);
    }
    
     public static void printDataOfAllProjects() {
        if (projects.isEmpty()) {
            System.out.println("THERE ARE NO PROJECTS...");
        }
        else{
            System.out.println("-------ALL PROJECTS-------");
            int counter=1;
            for (Project project : projects) {
                System.out.println("``PROJEC NUMBER("+counter+"):");
                System.out.println("Project ID: " + project.projectId);
                System.out.println("Project Name: " + project.projectName);
                System.out.println("Description: " + project.description);
                System.out.println("----------------");
                counter++;
            }
        }
    }
     public void projectInformation(){
            System.out.println("Project ID: " + projectId);
            System.out.println("Project Name: " +projectName);
            System.out.println("Description: " + description);
            System.out.println("");
            System.out.println("--PLANS OF THIS PROJECT:");
            for (Plan plan:plans ) {
                System.out.println("  ``PLAN ID: "+plan.getPlanId()+"\tNAME: "+plan.planName);
                System.out.println("    DATE OF:\tSTART: "+plan.start+"\tEND: "+plan.end);
                System.out.println("    THE EXPECTED TIME: "+plan.totalHours+" HOURS.");
                System.out.println("    DESCRIPTION: "+plan.description);
                System.out.println("\t------");
                plan.commentsInformation();
                plan.tasksInformation();
            }
            
     }
}
