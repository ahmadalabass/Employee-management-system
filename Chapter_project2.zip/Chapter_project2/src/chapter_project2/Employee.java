package chapter_project2;


import java.util.ArrayList;
import java.util.Date;

public class Employee {

    static int lastEmployeeId = 0;
    private int employeeId;
    String firstName;
    String lastName;
    String father;
    String mother;
    String username;
    String password;
    Date lastLogin;
    ArrayList<Comment> comments = new ArrayList<>();
    ArrayList<Task> tasks = new ArrayList<>();
    public void addTask(Task newTask) {
        tasks.add(newTask);
    }
    // قائمة ساكنة لتخزين جميع الموظفين
    static ArrayList<Employee> employees = new ArrayList<>();

    public Employee(String firstName, String lastName, String father,
            String mother, String username, String password,
            Date lastLogin) {
        this.employeeId = ++lastEmployeeId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.father = father;
        this.mother = mother;
        this.username = username;
        this.password = password;
        this.lastLogin = lastLogin;
        lastEmployeeId=this.employeeId;
    }

    public int getEmployeeId() {
        return employeeId;
    }
    

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    // دالة للتحقق مما إذا كان الحساب موجود
    public static boolean checkAccount(String username, String password) {
        for (Employee account : employees) {
            if (account.username.equals(username) && account.password.equals(password)) {
                return true;
            }
        }
        return false;
    }

    public static void addEmployee(Employee newEmployee) {
        employees.add(newEmployee);
    }

    //دالة تقوم بطباعة المعلومات 
     public static void printDataOfAllEmployee() {
        if (employees.isEmpty()) {
            System.out.println("THERE ARE NO EMPLOYEES...");
        }
        else{
            System.out.println("-------ALL EMPLOYEES-------");
            int counter=1;
            for (Employee employee : employees) {
                System.out.println("``EMPLOYEE NUMBER("+counter+"):");
                System.out.println("ID: " + employee.employeeId);
                System.out.println("First Name: " + employee.firstName);
                System.out.println("Last Name: " + employee.lastName);
                System.out.println("Father Name:" + employee.father);
                System.out.println("Mother Name:" + employee.mother);
                System.out.println("User:" + employee.username);
                System.out.println("Password: " + "not allow !!!");
                System.out.println("Last Login" + employee.lastLogin);
                System.out.println("number of his comment :"+employee.comments.size());
                System.out.println("number of his task :"+employee.tasks.size());
                System.out.println("----------------");
                counter++;
            }
        }
    }

}
