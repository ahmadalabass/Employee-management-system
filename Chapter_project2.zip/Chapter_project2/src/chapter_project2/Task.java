package chapter_project2;

import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class Task {

    private static int lastTaskId = 0;
    private int taskId;
    String taskName;
    Date startDate;
    Date endDate;
    String status;
    String description;
    int numberOfHours;
    Employee employee;//fk2
    Plan plan;//fk1
    Date completedDate;
    static ArrayList<Task> tasks = new ArrayList<>();
    
    public Task(String taskName, Date startDate, Date endDate, String description, int numberOfHours) {
        this.taskId = ++lastTaskId;
        this.taskName = taskName;
        this.startDate = startDate;
        this.endDate = endDate;
        this.status = "not completed yet";
        this.description = description;
        this.numberOfHours = numberOfHours;
        lastTaskId = this.taskId;
        this.plan = plan; 

    }
//   h تستقبل تاريخ اكتمال المهمة وتغير الحالة للاكتمال  الطلب
    public void completeTask(Date completedDate) {
        this.status = "Completed";
        this.completedDate = completedDate;
    }

    public int getId() {
        return taskId;
    }

    public static void addTask(Task newTask) { 
        tasks.add(newTask);
    }

        // i ًدالة لإرجاع المهام المكتملة بين تاريخين ولم تتجاوز مدتها أسبوع الطلب 
    public static ArrayList<Task> getCompletedTasksInWeek(Date startDate, Date endDate) {
        ArrayList<Task> completedTasks = new ArrayList<>();
        for (Task task : tasks) {
            if (task.completedDate != null && task.completedDate.after(startDate) && task.completedDate.before(endDate)) {
                long num_days = getDiffrentDate(task.startDate, task.endDate, TimeUnit.DAYS);// (الايام) اخر باراميتر وحدو الزمن الي بدي اياها
                if (num_days <= 7) {//خلال اسبوع  سبعة ايام
                    completedTasks.add(task);
                }
            }
        }
        return completedTasks;
    }
    
// دالة لحساب الفرق بين تاريخين بالايام 
    private static long getDiffrentDate(Date startDate, Date endDate, TimeUnit timeUnit) {
        long DiffrentDateMilleSeconds = endDate.getTime() - startDate.getTime();
        return timeUnit.convert(DiffrentDateMilleSeconds, TimeUnit.MILLISECONDS);
    }   //دالة ندخل لها الزمن و نوع الوحدة ثم يحول الزمن الى وحدة الايام   :convert
    
    
    //i , jالطلب (0/1/-1) دالة تستقبل تاريخين وتعيد حسب الوقت المتوقع بالايام
    public int getNumberOfExpectedTime(Date startDate , Date endDate){
        long expectedDays=getDiffrentDate(startDate, endDate, TimeUnit.DAYS);
        if (status.equals("Completed")) {
            long completedDays=getDiffrentDate(startDate, completedDate, TimeUnit.DAYS);
            if (expectedDays>completedDays) {
                return -1;
            }else if (expectedDays<completedDays) {
                return 1;
            }else{
                return 0;
            }
        }
        return 1;//لم تكنمل ايام اكتر من المتوقع
    }
//------------------------------
    // دالة طباعة معلومات المهام
public static void printDataOfAllTasks() {
        if (tasks.isEmpty()) {
            System.out.println("THERE ARE NO TASKS...");
        }
        else{
            System.out.println("-------ALL TASKS-------");
            int counter=1;
            for (Task task : tasks) {
                System.out.println("``TASK NUMBER("+counter+"):");
                System.out.println("task ID: " + task.taskId);
                System.out.println("taskName: " + task.taskName);
                System.out.println("date of start:" + task.startDate);
                System.out.println("date of end:" + task.endDate);
                System.out.println("total time: " +  task.numberOfHours+" hours");
                System.out.println("date of comleted:" + task.completedDate);
                System.out.println("status of task: " + task.status);
                System.out.println("description:" + task.description);
                System.out.println("task of employee's user: " +task.employee.username);
                System.out.println("task for plan: " + task.plan.planName);
                System.out.println("----------------");
                counter++;
            }
        }
    }
}
