package chapter_project2;

import java.util.ArrayList;

public class Plan {

    private static int lastPlanId = 0; 
    private int planId;
    String planName;
    String start;
    String end;
    int totalHours;
    String description;
    Project project;// fk
    ArrayList<Comment> comments = new ArrayList<>();
    ArrayList<Task> tasks = new ArrayList<>();
    static ArrayList<Plan> plans = new ArrayList<>();

//    (f)  عند اضافة مهمة يعدل الزمن الكلي للخطة    الطلب
    public void addTask(Task newTask) {
        tasks.add(newTask);
        this.totalHours+=newTask.numberOfHours;
    }

    public void addComment(Comment newComment) {
        comments.add(newComment);
    }

    public Plan(String planName, String start, String end, String description) {
        this.planId = ++lastPlanId;
        this.planName = planName;
        this.start = start;
        this.end = end;
        this.totalHours = 0;
        this.description = description;
        lastPlanId=this.planId;
    }

    public int getPlanId() {
        return planId;
    }

    // دالة لإضافة خطة جديد إلى قائمة الخطط
    public static void addPlan(Plan newPlan) {
        plans.add(newPlan);
    }

    // دالة طباعة معلومات الخطط
     public static void printDataOfAllPlans() {
        if (plans.isEmpty()) {
            System.out.println("THERE ARE NO PLANS...");
        }
        else{
            System.out.println("-------ALL PLANS-------");
            int counter=1;
            for (Plan plan : plans) {
                System.out.println("``PLAN NUMBER("+counter+"):");
                System.out.println("plan ID: " + plan.planId);
                System.out.println("plan Name: " + plan.planName);
                System.out.println("date of start:" + plan.start);
                System.out.println("date of end:" + plan.end);
                System.out.println("total time: " + plan.totalHours+" hours");
                System.out.println("description:" + plan.description);
                System.out.println("plan of project: " + plan.project.projectName);
                System.out.println("----------------");
                counter++;
            }
        }
    }
     
        public void commentsInformation(){
            if (comments.isEmpty()) {
                System.out.println("THERE ARE NO COMMENT ON THIS PLAN!!");
            }else{
                System.out.println("--COMMENTS ON THIS PLAN:");
                for (Comment comment:comments) {
                    for (Comment replie:Comment.replies) {
                        if (comment.getId()==replie.getId()) {
                            System.out.println("THIS COMMENT IS A REPLIE TO COMMENT THAT ID: ("+replie.comment.getId()+").");
                            System.out.println("\t  COMMENT \tID: "+comment.getId()+"\tCOMMENTER'S USERNAME:: "+comment.employee.firstName+" "+comment.employee.lastName);
                            System.out.println("\tCOMMENT TEXT: "+comment.commentText);
                    }else{
                    System.out.println("\t  COMMENT \tID: "+comment.getId()+"\tCOMMENTER'S USERNAME: "+comment.employee.username);
                    System.out.println("\tCOMMENT TEXT: "+comment.commentText);
                    System.out.println("\t------");
                        }
                    }
                }
            }
        }
        public void tasksInformation(){
            if (tasks.isEmpty()) {
                System.out.println("THERE ARE NO TASKS FOR THIS PLAN!!");
            }else{
            System.out.println("--TASKS OF THIS PLAN:");
                for (Task task:tasks) {
                    System.out.println("\tTASK \tID :"+task.getId()+"\tTASK NAME: "+task.taskName);
                    System.out.println("\tDATE \tSTART: "+task.startDate+"\tEND: "+task.endDate);
                    System.out.println("\tTHE EXPECTED TIME: "+task.numberOfHours+" HOURS.");
                    if (task.status.equals("not completed yet") ) {
                        System.out.println("\tSTATUS: "+task.status);
                        System.out.println("\t"+task.employee.firstName+" "+task.employee.lastName+" DIDN'T THIS TASK!!");
                    }else{
                        System.out.println("\tSTATUS: "+task.status+ " in date: "+task.completedDate);
                        System.out.println("\t"+task.employee.firstName+" "+task.employee.lastName+" DID THIS TASK..");
                    }
                    System.out.println("\t------");
                
            
            }
            }
        }
}
